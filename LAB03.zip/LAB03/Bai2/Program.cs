﻿using System;

namespace Bai2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            QuanLyTaiLieu qltl = new QuanLyTaiLieu();
            qltl.ChayChuongTrinh();
        }
    }

}