﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;

namespace Bai2
{
    public class TaiLieu
    {
        public int MaTaiLie { get; set; }
        public string NXB { get; set; }
        public int SoBanPhatHanh { get; set; }

        public TaiLieu() { }

        public virtual void Nhap()
        {
            Console.Write("Nhập mã tài liệu: ");
            MaTaiLie = int.Parse(Console.ReadLine());
            Console.Write("Nhap nha xuat ban: ");
            NXB = Console.ReadLine();
            Console.Write("Nhap so ban phat hanh: ");
            SoBanPhatHanh = int.Parse(Console.ReadLine());
        }

        public virtual void HienThi()
        {
            Console.WriteLine($"Ma tai lieu: {MaTaiLie}");
            Console.WriteLine($"Nha xuat ban: {NXB}");
            Console.WriteLine($"So ban phat hanh: {SoBanPhatHanh}");
        }
    }

    public class Sach : TaiLieu
    {
        public string TacGia { get; set; }
        public int SoTrang { get; set; }

        public override void Nhap()
        {
            base.Nhap();
            Console.Write("Nhap tac gia: ");
            TacGia = Console.ReadLine();
            Console.Write("Nhap so trang: ");
            SoTrang = int.Parse(Console.ReadLine());
        }

        public override void HienThi()
        {
            base.HienThi();
            Console.WriteLine($"Tac gia: {TacGia}");
            Console.WriteLine($"So trang: {SoTrang}");
        }
    }

    public class TapChi : TaiLieu
    {
        public int SoPhathanh { get; set; }
        public int ThangPhatHanh { get; set; }

        public override void Nhap()
        {
            base.Nhap();
            Console.Write("Nhap so phat hanh: ");
            SoPhathanh = int.Parse(Console.ReadLine());
            Console.Write("Nhap thang phat hanh: ");
            ThangPhatHanh = int.Parse(Console.ReadLine());
        }
        public override void HienThi()
        {
            base.HienThi();
            Console.WriteLine($"Số phát hành: {SoBanPhatHanh}");
            Console.WriteLine($"Tháng phát hành: ");
        }
    }
    public class Bao : TaiLieu
    {
        public string NgayPhatHanh { get; set; }

        public override void Nhap()
        {
            base.Nhap();
            Console.Write("Nhập ngày phát hành: ");
            NgayPhatHanh = Console.ReadLine();
        }

        public override void HienThi()
        {
            base.HienThi();
            Console.WriteLine($"Ngày phát hành: {NgayPhatHanh}");
        }
    }

    public class QuanLyTaiLieu
    {
        private List<TaiLieu> danhSachTaiLieu;

        public QuanLyTaiLieu()
        {
            danhSachTaiLieu = new List<TaiLieu>();
        }

        public void NhapThongTin()
        {
            Console.WriteLine("Chọn loại tài liệu (1-Sách, 2-Tạp chí, 3-Báo): ");
            int choice = int.Parse(Console.ReadLine());
            TaiLieu taiLieu = null;
            switch (choice)
            {
                case 1:
                    taiLieu = new Sach();
                    break;
                case 2:
                    taiLieu = new TapChi();
                    break;
                case 3:
                    taiLieu = new Bao();
                    break;
                default:
                    Console.WriteLine("Lựa chọn không hợp lệ.");
                    return;
            }
            taiLieu.Nhap();
            danhSachTaiLieu.Add(taiLieu);
            Console.WriteLine("Thêm tài liệu thành công!");
        }
        public void HienThiDanhSach()
        {
            if (danhSachTaiLieu.Count == 0)
            {
                Console.WriteLine("Danh sách tài liệu trống!");
                return;
            }

            Console.WriteLine("\n=== DANH SÁCH TÀI LIỆU ===");
            foreach (var taiLieu in danhSachTaiLieu)
            {
                taiLieu.HienThi();
                Console.WriteLine("------------------------");
            }
        }

        public void TimKiemTheoLoai()
        {
            Console.WriteLine("Chọn loại tài liệu cần tìm (1-Sách, 2-Tạp chí, 3-Báo): ");
            int choice;
            if (!int.TryParse(Console.ReadLine(), out choice))
            {
                Console.WriteLine("Lựa chọn không hợp lệ!");
                return;
            }

            Type loaiTaiLieu = null;
            switch (choice)
            {
                case 1:
                    loaiTaiLieu = typeof(Sach);
                    break;
                case 2:
                    loaiTaiLieu = typeof(TapChi);
                    break;
                case 3:
                    loaiTaiLieu = typeof(Bao);
                    break;
                default:
                    Console.WriteLine("Lựa chọn không hợp lệ!");
                    return;
            }

            bool found = false;
            Console.WriteLine($"\n=== DANH SÁCH {loaiTaiLieu.Name.ToUpper()} ===");
            foreach (var taiLieu in danhSachTaiLieu)
            {
                if (taiLieu.GetType() == loaiTaiLieu)
                {
                    taiLieu.HienThi();
                    Console.WriteLine("------------------------");
                    found = true;
                }
            }

            if (!found)
            {
                Console.WriteLine($"Không tìm thấy tài liệu loại {loaiTaiLieu.Name}!");
            }
        }

        public void ChayChuongTrinh()
        {
            while (true)
            {
                Console.WriteLine("\n=== QUẢN LÝ THƯ VIỆN ===");
                Console.WriteLine("1. Thêm tài liệu mới");
                Console.WriteLine("2. Hiển thị danh sách tài liệu");
                Console.WriteLine("3. Tìm kiếm tài liệu theo loại");
                Console.WriteLine("4. Thoát");
                Console.Write("Chọn chức năng: ");

                int choice;
                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    Console.WriteLine("Vui lòng nhập số hợp lệ!");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        NhapThongTin();
                        break;
                    case 2:
                        HienThiDanhSach();
                        break;
                    case 3:
                        TimKiemTheoLoai();
                        break;
                    case 4:
                        Console.WriteLine("Tạm biệt!");
                        return;
                    default:
                        Console.WriteLine("Chức năng không hợp lệ!");
                        break;
                }
            }
        }
    }
}
