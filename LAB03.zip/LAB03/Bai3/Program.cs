﻿using System;
using System.Collections.Generic;

abstract class ThiSinh
{
    public int SBD { get; set; }
    public string HoTen { get; set; }
    public string Diachi { get; set; }
    public int UuTien { get; set; }

    public ThiSinh(int sBD, string hoTen, string diachi, int uuTien)
    {
        SBD = sBD;
        HoTen = hoTen;
        Diachi = diachi;
        UuTien = uuTien;
    }

    public abstract double TinhTongDiem();
}

class ThiSinhKhoiA : ThiSinh
{
    public double Toan { get; set; }
    public double Ly { get; set; }
    public double Hoa { get; set; }
    public ThiSinhKhoiA(int sBD, string hoTen, string diachi, int uuTien, double toan, double ly, double hoa)
        : base(sBD, hoTen, diachi, uuTien)
    {
        Toan = toan;
        Ly = ly;
        Hoa = hoa;
    }
    public override double TinhTongDiem()
    {
        return Toan + Ly + Hoa + UuTien;
    }
}

class ThiSinhKhoiB : ThiSinh
{
    public double Toan { get; set; }
    public double Hoa { get; set; }
    public double Sinh { get; set; }
    public ThiSinhKhoiB(int sBD, string hoTen, string diachi, int uuTien, double toan, double hoa, double sinh)
        : base(sBD, hoTen, diachi, uuTien)
    {
        Toan = toan;
        Hoa = hoa;
        Sinh = sinh;
    }

    public override double TinhTongDiem()
    {
        return Toan + Hoa + Sinh + UuTien;
    }
}

class ThiSinhKhoiC : ThiSinh
{
    public double Van { get; set; }
    public double Su { get; set; }
    public double Dia { get; set; }
    public ThiSinhKhoiC(int sBD, string hoTen, string diachi, int uuTien, double van, double su, double dia)
        : base(sBD, hoTen, diachi, uuTien)
    {
        Van = van;
        Su = su;
        Dia = dia;
    }

    public override double TinhTongDiem()
    {
        return Van + Su + Dia + UuTien;
    }
}

class TuyenSinh
{
    private List<ThiSinh> danhSachThiSinh = new List<ThiSinh>();

    public void NhapThongTin()
    {
        Console.WriteLine("Nhập số lượng thí sinh: ");
        int n = int.Parse(Console.ReadLine());

        for(int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhập thí sinh thứ {n+1}: ");
            Console.WriteLine("Nhập SBD: ");
            int sBD = int.Parse(Console.ReadLine());
            Console.WriteLine("Nhập họ tên: ");
            string hoTen = Console.ReadLine();
            Console.WriteLine("Nhập địa chỉ: ");
            string diachi = Console.ReadLine();
            Console.WriteLine("Nhập ưu tiên: ");
            int uuTien = int.Parse(Console.ReadLine());
            Console.WriteLine("Chọn khối thi (1-A, 2-B, 3-C): ");
            int khoi = int.Parse(Console.ReadLine());

            switch (khoi)
            {
                case 1:
                    Console.WriteLine("Nhập điểm Toán: ");
                    double toanA = double.Parse(Console.ReadLine());
                    Console.WriteLine("Nhập điểm Lý: ");
                    double ly = double.Parse(Console.ReadLine());
                    Console.WriteLine("Nhập điểm Hóa: ");
                    double hoaA = double.Parse(Console.ReadLine());
                    danhSachThiSinh.Add(new ThiSinhKhoiA(sBD, hoTen, diachi, uuTien, toanA, ly, hoaA));
                    break;
                case 2:
                    Console.WriteLine("Nhập điểm Toán: ");
                    double toanB = double.Parse(Console.ReadLine());
                    Console.WriteLine("Nhập điểm Hóa: ");
                    double hoaB = double.Parse(Console.ReadLine());
                    Console.WriteLine("Nhập điểm Sinh: ");
                    double sinh = double.Parse(Console.ReadLine());
                    danhSachThiSinh.Add(new ThiSinhKhoiB(sBD, hoTen, diachi, uuTien, toanB, hoaB, sinh));
                    break;
                case 3:
                    Console.WriteLine("Nhập điểm Văn: ");
                    double van = double.Parse(Console.ReadLine());
                    Console.WriteLine("Nhập điểm Sử: ");
                    double su = double.Parse(Console.ReadLine());
                    Console.WriteLine("Nhập điểm Địa: ");
                    double dia = double.Parse(Console.ReadLine());
                    danhSachThiSinh.Add(new ThiSinhKhoiC(sBD, hoTen, diachi, uuTien, van, su, dia));
                    break;
            }

        }
    }

    public void HienThiDanhSachTrungTuyen()
    {
        Console.WriteLine("Danh sách thí sinh trúng tuyển: ");
        foreach (var thiSinh in danhSachThiSinh)
        {
            double tongDiem = thiSinh.TinhTongDiem();
            bool trungTuyen = false;
            if (thiSinh is ThiSinhKhoiA && tongDiem >= 15)
            {
                trungTuyen = true;
            }
            else if (thiSinh is ThiSinhKhoiB && tongDiem >= 18)
            {
                trungTuyen = true;
            }
            else if (thiSinh is ThiSinhKhoiC && tongDiem >= 20)
            {
                trungTuyen = true;
            }

            if (trungTuyen)
            {
                Console.WriteLine($"SBD: {thiSinh.SBD}, Họ tên: {thiSinh.HoTen}, Địa chỉ: {thiSinh.Diachi}, Tổng điểm: {tongDiem}");
            }
        }
    }

    public void TimKiemTheoSoBaoDanh()
    {
        Console.Write("\nNhap so bao danh can tim: ");
        int sBD = int.Parse(Console.ReadLine());
        bool found = false;

        foreach (var thiSinh in danhSachThiSinh)
        {
            if (thiSinh.SBD == sBD)
            {
                found = true;
                Console.WriteLine($"SBD: {thiSinh.SBD}, Ho ten: {thiSinh.HoTen}, Dia chi: {thiSinh.Diachi}, Uu tien: {thiSinh.UuTien}, Tong diem: {thiSinh.TinhTongDiem()}");
                if (thiSinh is ThiSinhKhoiA a)
                    Console.WriteLine($"Khoi A - Toan: {a.Toan}, Ly: {a.Ly}, Hoa: {a.Hoa}");
                else if (thiSinh is ThiSinhKhoiB b)
                    Console.WriteLine($"Khoi B - Toan: {b.Toan}, Hoa: {b.Hoa}, Sinh: {b.Sinh}");
                else if (thiSinh is ThiSinhKhoiC c)
                    Console.WriteLine($"Khoi C - Van: {c.Van}, Su: {c.Su}, Dia: {c.Dia}");
            }
        }

        if (!found)
            Console.WriteLine("Khong tim thay thi sinh voi so bao danh nay!");
    }

    public static void Main(string[] args)
    {
        TuyenSinh tuyenSinh = new TuyenSinh();
        while (true)
        {
            Console.WriteLine("\n=== Quan Ly Tuyen Sinh ===");
            Console.WriteLine("1. Nhap thong tin thi sinh");
            Console.WriteLine("2. Hien thi thi sinh trung tuyen");
            Console.WriteLine("3. Tim kiem theo so bao danh");
            Console.WriteLine("4. Ket thuc chuong trinh");
            Console.Write("Chon chuc nang: ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    tuyenSinh.NhapThongTin();
                    break;
                case 2:
                    tuyenSinh.HienThiDanhSachTrungTuyen();
                    break;
                case 3:
                    tuyenSinh.TimKiemTheoSoBaoDanh();
                    break;
                case 4:
                    Console.WriteLine("Ket thuc chuong trinh!");
                    return;
                default:
                    Console.WriteLine("Chuc nang khong hop le!");
                    break;
            }
        }
    }
}
