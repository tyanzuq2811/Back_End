﻿using System;
using System.Collections.Generic;

class Nguoi
{
    public int CMND { get; set; }
    public string HoTen { get; set; }
    public int Tuoi { get; set; }
    public int DiaChi { get; set; }
    public string NgheNghiep { get; set; }

    public Nguoi(int cmnd, string hoTen, int tuoi, int diaChi, string ngheNghiep)
    {
        CMND = cmnd;
        HoTen = hoTen;
        Tuoi = tuoi;
        DiaChi = diaChi;
        NgheNghiep = ngheNghiep;
    }

    public void HienThi()
    {
        Console.WriteLine($"CMND: {CMND}");
        Console.WriteLine($"Ho ten: {HoTen}");
        Console.WriteLine($"Tuoi: {Tuoi}");
        Console.WriteLine($"Dia chi: {DiaChi}");
        Console.WriteLine($"Nghe nghiep: {NgheNghiep}");
    }
}

class HoDan
{
    public int SoThanhVien { get; set; }
    public string SoNha { get; set; }   
    public List<Nguoi> DanhSachThanhVien { get; set; }

    public HoDan()
    {
        DanhSachThanhVien = new List<Nguoi>();
    }
    public void Nhap()
    {
        Console.Write("Nhap so thanh vien: ");
        SoThanhVien = int.Parse(Console.ReadLine());
        Console.Write("Nhap so nha: ");
        SoNha = Console.ReadLine();

        for (int i = 0; i < SoThanhVien; i++)
        {
            Console.WriteLine($"Nhap thong tin thanh vien {i + 1}:");
            Console.Write("CMND: ");
            int cmnd = int.Parse(Console.ReadLine());
            Console.Write("Ho ten: ");
            string hoTen = Console.ReadLine();
            Console.Write("Tuoi: ");
            int tuoi = int.Parse(Console.ReadLine());
            Console.Write("Dia chi: ");
            int diaChi = int.Parse(Console.ReadLine());
            Console.Write("Nghe nghiep: ");
            string ngheNghiep = Console.ReadLine();
            Nguoi nguoi = new Nguoi(cmnd, hoTen, tuoi, diaChi, ngheNghiep);
            DanhSachThanhVien.Add(nguoi);
        }

        public void HienThi()
    {
        Console.WriteLine($"So nha: {SoNha}, So thanh vien: {SoThanhVien}");
        Console.WriteLine("Danh sach thanh vien:");
        foreach (var nguoi in DanhSachNguoi)
        {
            nguoi.HienThi();
        }
        Console.WriteLine("-------------------");
    }
}

class KhuPho
{
    private List<HoDan> danhSachHoDan = new List<HoDan>();

    public void NhapDanhSachHoDan()
    {
        Console.Write("Nhap so luong ho dan: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap thong tin ho dan thu {i + 1}:");
            HoDan hoDan = new HoDan();
            hoDan.Nhap();
            danhSachHoDan.Add(hoDan);
        }
    }

    public void HienThiDanhSachHoDan()
    {
        Console.WriteLine("\nDanh sach cac ho dan trong khu pho:");
        foreach (var hoDan in danhSachHoDan)
        {
            hoDan.HienThi();
        }
    }

    public void TimKiemTheoHoTen()
    {
        Console.Write("\nNhap ho ten can tim: ");
        string hoTen = Console.ReadLine();
        bool found = false;

        foreach (var hoDan in danhSachHoDan)
        {
            foreach (var nguoi in hoDan.DanhSachNguoi)
            {
                if (nguoi.HoTen.ToLower().Contains(hoTen.ToLower()))
                {
                    found = true;
                    Console.WriteLine($"Tim thay trong ho dan so nha: {hoDan.SoNha}");
                    nguoi.HienThi();
                }
            }
        }

        if (!found)
            Console.WriteLine("Khong tim thay nguoi co ho ten nay!");
    }

    public void TimKiemTheoSoNha()
    {
        Console.Write("\nNhap so nha can tim: ");
        string soNha = Console.ReadLine();
        bool found = false;

        foreach (var hoDan in danhSachHoDan)
        {
            if (hoDan.SoNha == soNha)
            {
                found = true;
                hoDan.HienThi();
            }
        }

        if (!found)
            Console.WriteLine("Khong tim thay ho dan voi so nha nay!");
    }

    public static void Main(string[] args)
    {
        KhuPho khuPho = new KhuPho();
        while (true)
        {
            Console.WriteLine("\n=== Quan Ly Khu Pho ===");
            Console.WriteLine("1. Nhap thong tin cac ho dan");
            Console.WriteLine("2. Hien thi thong tin cac ho dan");
            Console.WriteLine("3. Tim kiem theo ho ten");
            Console.WriteLine("4. Tim kiem theo so nha");
            Console.WriteLine("5. Thoat chuong trinh");
            Console.Write("Chon chuc nang: ");
            int choice;
            if (!int.TryParse(Console.ReadLine(), out choice))
            {
                Console.WriteLine("Vui long nhap so hop le!");
                continue;
            }

            switch (choice)
            {
                case 1:
                    khuPho.NhapDanhSachHoDan();
                    break;
                case 2:
                    khuPho.HienThiDanhSachHoDan();
                    break;
                case 3:
                    khuPho.TimKiemTheoHoTen();
                    break;
                case 4:
                    khuPho.TimKiemTheoSoNha();
                    break;
                case 5:
                    Console.WriteLine("Ket thuc chuong trinh!");
                    return;
                default:
                    Console.WriteLine("Chuc nang khong hop le!");
                    break;
            }
        }
    }
}