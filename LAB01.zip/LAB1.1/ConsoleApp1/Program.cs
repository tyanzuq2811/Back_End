﻿using System;
using System.Runtime.Intrinsics.X86;
using LAB01;

namespace BaiTap
{
    class Program
    {
        static void Main(string[] args)
        {
            //Bai1.Run(); 
            //Bai2.Run();
            //Bai3.Run();
            //Bai4.Run();
            //Bai5.Run();
            //Bai6.Run();
            //Bai7.Run();
            //Bai8.Run();
            //Bai9.Run();
            Bai10.Run();
        }
    }
}
