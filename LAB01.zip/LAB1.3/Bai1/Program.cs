﻿using System;

namespace Bai1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            QLCB qlcb = new QLCB();
            qlcb.ChayChuongTrinh();
        }
    }
}